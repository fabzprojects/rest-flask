from flask import Flask, render_template, request, redirect,  flash, abort, url_for
# from vadhyakalakshethra import app,db,bcrypt,mail
from sample import app
from sample import app
from sample.models import *
# from sample.forms import *
# from flask_login import login_user, current_user, logout_user, login_required
# from random import randint
# import os
# from PIL import Image
# from flask_mail import Message


@app.route('/')
def welcome(): 
    return render_template("welcome.html")

