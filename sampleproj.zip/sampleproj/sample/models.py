from sample import app
# from sample import db,app




# from sample import db,app,login_manager
# from flask_login import UserMixin
# from flask_table import Table, Col, LinkCol
# from itsdangerous import TimedJSONWebSignatureSerializer as Serializer

# @login_manager.user_loader
# def load_user(id):
#     return Login.query.get(int(id))



# class Login(db.Model, UserMixin):
#     id=db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(80))
#     password = db.Column(db.String(80))
#     usertype = db.Column(db.String(80))
  

 





